﻿using Microsoft.AspNetCore.Identity;

namespace IdenTTY.Models
{
    public class AppIdentityUser : IdentityUser
    {
        public int Age { get; set; }
    }
}
