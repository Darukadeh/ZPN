﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace IdenTTY.Models
{
    public class IdenTTYContext  : IdentityDbContext<AppIdentityUser, AppIdentityRole, string>
    {
        public IdenTTYContext (DbContextOptions<IdenTTYContext> options)
            : base(options)
        {
        }

        public DbSet<IdenTTY.Models.Person> Person { get; set; }
    }
}
