﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdenTTY.ViewComponents
{
    public class SiteCopyright : ViewComponent
    {
        public IViewComponentResult Invoke(int numberToTake)
        {
            var name = "Hadi "+ numberToTake;
            return View(viewName: "Default", model: name);
        }

        //public async Task<IViewComponentResult> InvokeAsync(int numberToTake)
        //{
        //    return View();
        //}
    }
}